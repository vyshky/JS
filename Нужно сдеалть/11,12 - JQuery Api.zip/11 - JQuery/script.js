//js
//document.querySelector('p').innerText = 'Farid';
//document.querySelector('.myP').innerText = 'Farid 2';
// let ps = document.querySelectorAll('p');
// for (const p of ps) {
//     p.innerText = 'Farid';
// }
//  let ps = document.querySelectorAll('p');
// ps[2].innerText = "Farid";
// let p = document.querySelector('p');
// console.log(p.innerText);
// document.querySelector('button')
// .addEventListener('click',function () {
//     document.querySelector('p').innerText = "Farid";
// })

// function MyFunc() {
//     document.querySelector('p').innerText = "Good";
// }

// document.querySelector('button').addEventListener('click',MyFunc);



//jq
//$('p').text('Farid');
//$('.myP').text('Farid 3');
//$('p').text('Farid');
//$('p:last').text('Farid');
// console.log($('p:last').text());
// console.log($('p').text());
//console.log($('input').val());;
//  $('p').css('color','red');
// ///$('p').css('font-size','50px');
// console.log($('p').css('color'));
// console.log($('p').css('font-size'));
//$('p').css({'color':'red','font-size':'50px','background-color':'green'});
//$('p').attr("data-id",100)
//  $('p').attr("title",'my Farid');
//  $('p').removeAttr('title');
// console.log($('p').attr('title'));
//$('p').attr('id','hello')
// $('p').addClass('myDiz');
// $('p').addClass('myDiz2');
// $('p').addClass(['myDiz','myDiz2']);
// $('p').removeClass('myDiz');

//  function MyFunc() {
//     $('p').text('Good');
//  }

// $('button').click(MyFunc);



// $('.one').click(function(){
//     $('p').addClass('myDiz');
// });

// $('.two').click(function(){
//     $('p').removeClass('myDiz');
// });


// $('button').click(function(){
//     if ($('p').hasClass('myDiz')) {
//         $('p').removeClass('myDiz');
//     }else{
//         $('p').addClass('myDiz');
//     }
// });




// $('button').click(function(){
//    $('p').toggleClass('myDiz');
// });


// $('button').click(function(){

//     $('p').text(Math.floor(Math.random() * 10)).toggleClass('myDiz');
//  });




// $('.one').click(function() {
//     $('p').hide(500);
// });

// $('.two').click(function() {
//     $('p').show(500);
// });


// $('button').click(function() {
//     $('p').toggle(700); 
// });


// $('.one').click(function() {
//      $('p').fadeOut(1000); 
// });

// $('.two').click(function() {
//     // $('p').fadeIn(1000);
// });


// $('button').click(function() {
//     $('p').fadeToggle(700); 
// });


$('button').click(function() {
   // $('p').append("text"); 
   //$('p').append("<h1>text</h1>"); 

//    $('p').prepend("text");
//    $('p').prepend("<h1>text</h1>"); 

//    $('p').after("text");
//    $('p').after("<h1>text</h1>");

// $('p').before("text");
// $('p').before("<h1>text</h1>");


//$('p').before($('button').clone());
//$('p').before($('button').clone(true,false));
});

